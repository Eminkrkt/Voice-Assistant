# Sesli-Asistan-3.0

**_Turkish_**
* 2 işletim sisteminde çalışabilen sesli asistan.(Linux ve Windows)

> Kullanıcı kayıt bölümü vardır. Program eğer kayıtlı bilgi bulamaz ise yeni kayıt oluşturur.
> Asistan ile konuşmaların hepsi yazılımın geliştirilebilmesi için "old_words.txt" dosyasında depolanır.

* Sesli-Asistan-3.0 Neler Yapabilir ?

* Varsayılan tarayıcınız üzerinden yeni sekmeler açabilir .  ```internette ara```
* Sizin dediklerinizi tekrarlayabilir .                      ```dediklerimi tekrarla```
* Wikipedia da arama yapabilir .                             ```wikipedia```
* Youtube üzerinden arama yapabilir .                        ```youtube aç```
* İnstagram açabilir .                                       ```instagram aç```
* Bilgisayarı kapatır ve yeniden başlatabilir .              ```bilgisayarı kapat ve ya bilgisayarı yeniden başlat```

**_English_**
* Voice assistant that can run on both operating systems (Linux and Windows)

> There is a user registration section. If the program cannot find the registered information, it creates a new record. 
> All conversations with the Assistant are stored in the "old_words.txt" file so that the software can be developed.

>The software continues to be developed for English.
